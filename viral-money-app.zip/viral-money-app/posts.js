const posts = [
{title:"🤖 7 famosos recreados con IA que parecen reales", body:"Una colección viral de imágenes y curiosidades sobre cómo la IA recrea celebridades con resultados sorprendentes."},
{title:"⚽ Top 5 goles imposibles de la semana", body:"Resumen rápido de clips y curiosidades de fútbol que enganchan muchísimo y se comparten fácil."},
{title:"🧠 Test viral: ¿eres más listo que una IA?", body:"Mini reto de preguntas rápidas para aumentar tiempo en página y compartir en redes."},
{title:"🔥 10 datos locos de futbolistas millonarios", body:"Curiosidades sobre coches, mansiones y negocios que generan mucho CTR."},
{title:"😂 Memes virales del día", body:"Contenido ultra rápido para scroll infinito y más visualizaciones por usuario."},
{title:"💰 5 herramientas de IA para ganar dinero", body:"Tutoriales rápidos y útiles que suelen tener mejor CPM."}
];