# ViralIA Money
Tema elegido: IA + fútbol + famosos + memes.
Es de los nichos más entretenidos y con mejor potencial de RPM por mezcla de viralidad + CPM tecnológico.

## Cómo publicarlo gratis
1. Sube esta carpeta a GitHub
2. Importa el repo en Vercel
3. Publica
4. Solicita Google AdSense cuando tengas 20-30 posts

## Para ganar más
- Publica 3-5 posts diarios
- Usa TikTok / Reels para mandar tráfico
- Añade nuevas listas en posts.js
